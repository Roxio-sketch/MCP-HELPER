rootProject.name = "mcp-common"
