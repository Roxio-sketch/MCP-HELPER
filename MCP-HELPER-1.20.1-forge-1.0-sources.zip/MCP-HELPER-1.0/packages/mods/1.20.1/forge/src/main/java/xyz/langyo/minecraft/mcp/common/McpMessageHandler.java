package xyz.langyo.minecraft.mcp.common;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class McpMessageHandler {

    private static final Gson GSON = McpProtocol.GSON;
    protected McpProtocol.MinecraftInput minecraftInput;
    private int reqId = 0;

    public McpMessageHandler() {}


    public void sendInit(Object wsClient) {
    }

    public void handleMessage(String raw, Object wsClient) {
        try {
            JsonObject msg = GSON.fromJson(raw, JsonObject.class);
            JsonElement methodEl = msg.get("method");
            if (methodEl == null) {
                return;
            }
            String method = methodEl.getAsString();
            java.util.Map<String, String> params = new java.util.LinkedHashMap<>();
            JsonObject paramsObj = msg.getAsJsonObject("params");
            if (paramsObj != null) {
                for (java.util.Map.Entry<String, JsonElement> e : paramsObj.entrySet()) {
                    params.put(e.getKey(), e.getValue().isJsonNull() ? "" : e.getValue().getAsString());
                }
            }
            Object result = dispatch(method, params, wsClient);
            sendResponse(method, result, wsClient, params.get("requestId"));
        } catch (Exception e) {
            System.err.println("[MCP-Handler] Error: " + e.getMessage());
        }
    }

    private static final java.util.Set<String> ALWAYS_ALLOWED;
    static {
        java.util.Set<String> s = new java.util.HashSet<>();
        s.add("ping"); s.add("screenshot"); s.add("get_player_info"); s.add("get_world_info"); s.add("debug_fields");
        s.add("get_screen_buttons"); s.add("enumerate_widgets"); s.add("overlay_click");
        s.add("enter_control_mode"); s.add("exit_control_mode");
        s.add("set_gamemode"); s.add("release_mouse"); s.add("pause_game"); s.add("close_screen"); s.add("open_chat");
        s.add("open_to_lan"); s.add("set_no_pause"); s.add("set_mouse_sharing"); s.add("get_connection_info");
        s.add("get_port"); s.add("set_port");
        s.add("spawn_helper"); s.add("helper_info"); s.add("helper_goto_player");
        s.add("helper_move"); s.add("helper_command"); s.add("helper_remove");
        ALWAYS_ALLOWED = java.util.Collections.unmodifiableSet(s);
    }

    protected Object dispatch(String method, java.util.Map<String, String> params, Object wsClient) {
        McpProtocol.MinecraftInput inp = minecraftInput;
        if (inp == null) {
            return "error: no input handler bound";
        }
        if (method.equals("ping")) return "pong";
        if (method.equals("screenshot")) return handleScreenshot();
        if (method.equals("screenshot_to_file")) return handleScreenshotToFile(params);
        if (method.equals("overlay_click")) return handleOverlayClick(params);
        if (method.equals("enter_control_mode") || method.equals("exit_control_mode")) return handleControlMode(params, method);
        if (method.equals("open_to_lan")) return handleOpenToLan(params);
        if (method.equals("set_no_pause")) return handleSetNoPause(params);
        if (method.equals("set_mouse_sharing")) return handleSetMouseSharing(params);
        if (method.equals("get_connection_info")) return handleGetConnectionInfo();
        // ===== 端口配置：9876 已改为可配置 =====
        if (method.equals("get_port")) return handleGetPort();
        if (method.equals("set_port")) return handleSetPort(params);
        // ===== MCP-HELPER：AI 的独立身体 =====
        if (method.equals("spawn_helper")) return handleSpawnHelper();
        if (method.equals("helper_info")) return handleHelperInfo();
        if (method.equals("helper_goto_player")) return handleHelperGotoPlayer();
        if (method.equals("helper_move")) return handleHelperMove(params);
        if (method.equals("helper_command")) return handleHelperCommand(params);
        if (method.equals("helper_remove")) return handleHelperRemove();

        boolean inControl = ReflectionHelper.isMcpControlMode();
        if (!inControl && !ALWAYS_ALLOWED.contains(method)) {
            return "{\"error\":\"not in control mode\",\"hint\":\"Enter control mode via ESC > MCP Take Over\"}";
        }
        if (method.equals("click")) return handleClick(params);
        if (method.equals("press_key")) return handlePressKey(params);
        if (method.equals("type_text")) return handleTypeText(params);
        if (method.equals("scroll")) return handleScroll(params);
        if (method.equals("scroll_at")) return handleScrollAt(params);
        if (method.equals("direct_scroll")) return handleDirectScroll(params);
        if (method.equals("select_list_item")) return handleSelectListItem(params);
        if (method.equals("mouse_drag") || method.equals("drag")) return handleMouseDrag(params);
        if (method.equals("hotkey")) return handleHotkey(params);
        if (method.equals("execute_command")) return handleExecuteCommand(params);
        if (method.equals("get_player_info")) return handleGetPlayerInfo();
        if (method.equals("get_world_info")) return handleGetWorldInfo();
        if (method.equals("debug_fields")) return handleDebugFields();
        if (method.equals("get_screen_buttons")) return handleGetScreenButtons();
        if (method.equals("click_button_id")) return handleClickButtonId(params);
        if (method.equals("click_button_index")) return handleClickButtonIndex(params);
        if (method.equals("enumerate_widgets")) return handleEnumerateWidgets(params);
        if (method.equals("call_screen_method")) return handleCallScreenMethod(params);
        if (method.equals("paste_text")) return handlePasteText(params);
        if (method.equals("set_view_angle")) return handleSetViewAngle(params);
        if (method.equals("look_delta")) return handleLookDelta(params);
        if (method.equals("right_click")) return handleRightClick();
        if (method.equals("use_item")) return handleUseItem();
        if (method.equals("place_block")) return handlePlaceBlock();
        if (method.equals("pause_game")) return handlePauseGame();
        if (method.equals("open_chat")) return handleOpenChat();
        if (method.equals("close_screen")) return handleCloseScreen();
        if (method.equals("release_mouse")) return handleReleaseMouse();
        if (method.equals("set_gamemode")) return handleSetGameMode(params);
        if (method.equals("switch_tab")) return handleSwitchTab(params);

        return "unknown: " + method;
    }

    private void sendResponse(String method, Object result, Object wsClient, String requestId) {
    }

    protected Object handleOverlayClick(java.util.Map<String, String> params) {
        int x = 0, y = 0;
        try { x = Integer.parseInt(params.getOrDefault("x", "0")); } catch (Exception ignored) {}
        try { y = Integer.parseInt(params.getOrDefault("y", "0")); } catch (Exception ignored) {}
        final int fx = x, fy = y;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try {
                Object mc = ReflectionHelper.getMinecraftInstance();
                result[0] = ReflectionHelper.handleOverlayClick(fx, fy, mc);
            } catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleControlMode(java.util.Map<String, String> params, String method) {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        // 鼠标策略：默认 shared（玩家保留视角）。detached 为旧的“AI 独占鼠标”行为。
        boolean detach = !ControlModeHelper.isMouseSharing();
        String mode = params.get("mode");
        if (mode == null || mode.isEmpty()) mode = params.get("mouse");
        if (mode == null || mode.isEmpty()) {
            String rm = params.get("release_mouse");
            if (rm != null && ("true".equalsIgnoreCase(rm) || "1".equals(rm))) mode = "detached";
        }
        if (mode != null) {
            String m = mode.trim().toLowerCase(java.util.Locale.ROOT);
            detach = m.equals("detached") || m.equals("release") || m.equals("free_cursor") || m.equals("exclusive");
        }
        final boolean fdetach = detach;
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try {
                Object mc = ReflectionHelper.getMinecraftInstance();
                if (method.equals("enter_control_mode")) {
                    result[0] = ReflectionHelper.enterMcpControlMode(mc, fdetach);
                } else {
                    result[0] = ReflectionHelper.exitMcpControlMode(mc);
                }
            } catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleOpenToLan(java.util.Map<String, String> p) {
        int port = 25565;
        try { port = Integer.parseInt(p.getOrDefault("port", "25565")); } catch (Exception ignored) {}
        boolean allowCheats = true;
        String ac = p.get("allow_cheats");
        if (ac != null && ("false".equalsIgnoreCase(ac) || "0".equals(ac))) allowCheats = false;
        final int fport = port;
        final boolean fcheats = allowCheats;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.openToLan(ReflectionHelper.getMinecraftInstance(), fport, fcheats); }
            catch (Exception e) { result[0] = JsonHelper.builder().put("ok", false).error(e.getMessage()).build(); }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleSetNoPause(java.util.Map<String, String> p) {
        boolean enabled = true;
        String v = p.get("enabled");
        if (v == null) v = p.get("no_pause");
        if (v != null && ("false".equalsIgnoreCase(v) || "0".equals(v))) enabled = false;
        ReflectionHelper.setNoPause(enabled);
        return "{\"no_pause\":" + enabled + ",\"note\":\"applies to the vanilla singleplayer pause screen\"}";
    }

    protected Object handleSetMouseSharing(java.util.Map<String, String> p) {
        boolean shared = true;
        String v = p.get("enabled");
        if (v == null) v = p.get("shared");
        if (v != null && ("false".equalsIgnoreCase(v) || "0".equals(v))) shared = false;
        final boolean fshared = shared;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.setMouseSharing(ReflectionHelper.getMinecraftInstance(), fshared); }
            catch (Exception e) { result[0] = JsonHelper.builder().error(e.getMessage()).build(); }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleGetConnectionInfo() {
        try { return ReflectionHelper.getConnectionInfo(ReflectionHelper.getMinecraftInstance()); }
        catch (Exception e) { return JsonHelper.builder().error(e.getMessage()).build(); }
    }

    /** 查询当前 HTTP 服务端口与端口来源。 */
    protected Object handleGetPort() {
        McpHttpServer server = McpHttpServer.getActive();
        return JsonHelper.builder()
                .put("default_port", McpConfig.DEFAULT_PORT)
                .put("configured_port", McpConfig.getServerPort())
                .put("active_port", server != null ? server.getPort() : -1)
                .put("source", McpConfig.getPortSource())
                .put("running", server != null && server.isRunning())
                .put("url", "http://127.0.0.1:" + McpConfig.getServerPort())
                .put("config_file", McpConfig.getConfigFile().toAbsolutePath().toString())
                .build();
    }

    /**
     * 修改端口：写入配置文件，并在后台把 HTTP 服务重启到新端口。
     * 重启放在独立线程里，保证这条命令的 HTTP 应答能先发回去。
     */
    protected Object handleSetPort(java.util.Map<String, String> p) {
        String raw = p.get("port");
        if (raw == null || raw.trim().isEmpty()) return JsonHelper.error("missing port");
        int port;
        try {
            port = Integer.parseInt(raw.trim());
        } catch (NumberFormatException e) {
            return JsonHelper.error("invalid port: " + raw);
        }
        if (!McpConfig.isValidPort(port)) return JsonHelper.error("port out of range (1-65535): " + port);
        boolean saved = McpConfig.setConfiguredPort(port);
        final int target = port;
        Thread restarter = new Thread(() -> {
            try {
                Thread.sleep(300);
                McpHttpServer.restartOnPort(target);
            } catch (InterruptedException ignored) {
            } catch (Exception e) {
                System.err.println("[MCP-MOD] set_port restart failed on " + target + ": " + e.getMessage());
            }
        }, "MCP-PORT-RESTART");
        restarter.setDaemon(true);
        restarter.start();
        return JsonHelper.builder()
                .put("ok", true)
                .put("port", port)
                .put("saved", saved)
                .put("restarting", true)
                .put("url", "http://127.0.0.1:" + port)
                .put("hint", "HTTP 服务正在切到新端口，SSE 连接会断开重连")
                .build();
    }

    protected Object handleScreenshot() {
        try {
            byte[] bytes = minecraftInput != null ? minecraftInput.screenshot() : null;
            if (bytes != null) {
                return "data:image/png;base64," + java.util.Base64.getEncoder().encodeToString(bytes);
            }
            return "error: screenshot returned null";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    protected Object handleScreenshotToFile(java.util.Map<String, String> p) {
        String filePath = p.get("path");
        if (filePath == null || filePath.isEmpty()) return "{\"error\":\"missing path\"}";
        try {
            byte[] bytes = minecraftInput != null ? minecraftInput.screenshot() : null;
            if (bytes == null) return "{\"error\":\"screenshot returned null\"}";
            java.nio.file.Path fp = java.nio.file.Paths.get(filePath);
            java.nio.file.Files.createDirectories(fp.getParent());
            java.nio.file.Files.write(fp, bytes);
            return "{\"file\":\"" + fp.toAbsolutePath().toString().replace("\\", "\\\\") + "\",\"size\":" + bytes.length + "}";
        } catch (Exception e) {
            return "{\"error\":\"" + e.getMessage().replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
        }
    }

    protected Object handleClick(java.util.Map<String, String> p) {
        String xStr = p.get("x");
        String yStr = p.get("y");
        if (xStr == null || yStr == null) return "missing x or y";
        int x = Integer.parseInt(xStr);
        int y = Integer.parseInt(yStr);
        String button = p.getOrDefault("button", "left");
        if (minecraftInput != null) {
            minecraftInput.click(x, y, button);
            return ReflectedInputHandler.getLastClickResult();
        }
        return "{\"error\":\"no handler\"}";
    }

    protected Object handlePressKey(java.util.Map<String, String> p) {
        String key = p.get("key");
        if (key == null) return "{\"error\":\"missing key\"}";
        float hold = 0f;
        String holdStr = p.get("hold_seconds");
        if (holdStr != null) {
            try { hold = Float.parseFloat(holdStr); } catch (NumberFormatException ignored) {}
        }
        if (minecraftInput != null) minecraftInput.pressKey(key, hold);
        return "{\"pressed\":\"" + key + "\"}";
    }

    protected Object handleTypeText(java.util.Map<String, String> p) {
        String text = p.get("text");
        if (text == null) return "missing text";
        if (minecraftInput != null) {
            minecraftInput.typeText(text);
            if ("true".equals(p.get("press_enter"))) {
                minecraftInput.pressKey("Enter", 0f);
            }
        }
        return text;
    }

    protected Object handleScroll(java.util.Map<String, String> p) {
        int clicks = 1;
        String clicksStr = p.get("clicks");
        if (clicksStr != null) {
            try { clicks = Integer.parseInt(clicksStr); } catch (NumberFormatException ignored) {}
        }
        if (minecraftInput != null) minecraftInput.scroll(clicks);
        return "{\"scrolls\":" + clicks + "}";
    }

    protected Object handleScrollAt(java.util.Map<String, String> p) {
        int x = 0, y = 0;
        try { x = Integer.parseInt(p.getOrDefault("x", "0")); } catch (Exception ignored) {}
        try { y = Integer.parseInt(p.getOrDefault("y", "0")); } catch (Exception ignored) {}
        int clicks = 1;
        String clicksStr = p.get("clicks");
        if (clicksStr != null) {
            try { clicks = Integer.parseInt(clicksStr); } catch (NumberFormatException ignored) {}
        }
        if (minecraftInput != null) minecraftInput.scrollAt(x, y, clicks);
        return "{\"scroll_at\":true,\"x\":"+x+",\"y\":"+y+",\"clicks\":"+clicks+"}";
    }

    protected Object handleSelectListItem(java.util.Map<String, String> p) {
        int index = 0;
        try { index = Integer.parseInt(p.getOrDefault("index", "0")); } catch (Exception ignored) {}
        return ReflectionHelper.selectListItem(ReflectionHelper.getMinecraftInstance(), index);
    }

    protected Object handleDirectScroll(java.util.Map<String, String> p) {
        double mouseX = -1, mouseY = -1, delta = 1.0;
        try { mouseX = Double.parseDouble(p.getOrDefault("mouseX", "-1")); } catch (Exception ignored) {}
        try { mouseY = Double.parseDouble(p.getOrDefault("mouseY", "-1")); } catch (Exception ignored) {}
        try { delta = Double.parseDouble(p.getOrDefault("delta", "1")); } catch (Exception ignored) {}
        return ReflectionHelper.directScroll(ReflectionHelper.getMinecraftInstance(), mouseX, mouseY, delta);
    }

    protected Object handleMouseDrag(java.util.Map<String, String> p) {
        int x1 = 0, y1 = 0, x2 = 0, y2 = 0;
        try { x1 = Integer.parseInt(p.getOrDefault("x1", p.getOrDefault("x_start", "0"))); } catch (Exception ignored) {}
        try { y1 = Integer.parseInt(p.getOrDefault("y1", p.getOrDefault("y_start", "0"))); } catch (Exception ignored) {}
        try { x2 = Integer.parseInt(p.getOrDefault("x2", p.getOrDefault("x_end", "0"))); } catch (Exception ignored) {}
        try { y2 = Integer.parseInt(p.getOrDefault("y2", p.getOrDefault("y_end", "0"))); } catch (Exception ignored) {}
        String button = p.getOrDefault("button", "left");
        if (minecraftInput != null) minecraftInput.mouseDrag(x1, y1, x2, y2, button);
        return "{\"drag\":true,\"from\":[" + x1 + "," + y1 + "],\"to\":[" + x2 + "," + y2 + "]}";
    }

    protected Object handleHotkey(java.util.Map<String, String> p) {
        String keysStr = p.get("keys");
        if (keysStr == null) return "missing keys";
        String[] keys = keysStr.split(",");
        for (int i = 0; i < keys.length; i++) keys[i] = keys[i].trim();
        if (minecraftInput != null) minecraftInput.hotkey(keys);
        return keysStr;
    }

    protected Object handleExecuteCommand(java.util.Map<String, String> p) {
        String cmd = p.get("command");
        if (cmd == null) return "missing command";
        String asHelper = p.get("as_helper");
        if (asHelper != null && ("true".equalsIgnoreCase(asHelper) || "1".equals(asHelper))) {
            net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
            if (mc == null) return "{\"error\":\"no minecraft instance\"}";
            return HelperPlayerManager.executeAsHelper(mc, cmd);
        }
        if (minecraftInput != null) return minecraftInput.executeCommand(cmd);
        return "error: no input handler";
    }

    // ===== MCP-HELPER：独立身体相关命令 =====

    protected Object handleSpawnHelper() {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        return HelperPlayerManager.spawn(mc);
    }

    protected Object handleHelperInfo() {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        return HelperPlayerManager.info(mc);
    }

    protected Object handleHelperGotoPlayer() {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        return HelperPlayerManager.teleportToPlayer(mc);
    }

    protected Object handleHelperMove(java.util.Map<String, String> p) {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        return HelperPlayerManager.move(mc, p);
    }

    protected Object handleHelperCommand(java.util.Map<String, String> p) {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        String cmd = p.get("command");
        if (cmd == null) return "{\"error\":\"missing command\"}";
        return HelperPlayerManager.executeAsHelper(mc, cmd);
    }

    protected Object handleHelperRemove() {
        net.minecraft.client.Minecraft mc = McBridge.asMc(ReflectionHelper.getMinecraftInstance());
        if (mc == null) return "{\"error\":\"no minecraft instance\"}";
        return HelperPlayerManager.remove(mc);
    }

    protected Object handleGetPlayerInfo() {
        if (minecraftInput != null) return minecraftInput.getPlayerInfo();
        return "no player";
    }

    protected Object handleGetWorldInfo() {
        if (minecraftInput != null) return minecraftInput.getWorldInfo();
        return "no world";
    }

    protected Object handleDebugFields() {
        if (minecraftInput != null) return minecraftInput.debugFields();
        return "no input handler";
    }

    protected Object handleGetScreenButtons() {
        if (minecraftInput != null) return ReflectionHelper.getScreenButtons(ReflectionHelper.getMinecraftInstance());
        return "no input handler";
    }

    protected Object handleClickButtonId(java.util.Map<String, String> params) {
        if (minecraftInput != null) {
            int id = 0;
            try { id = Integer.parseInt(params.getOrDefault("id", params.get("button_id"))); } catch (Exception ignored) {}
            final int fid = id;
            final CountDownLatch latch = new CountDownLatch(1);
            final String[] result = {""};
            ReflectedInputHandler.executeOnRenderThread(() -> {
                try { result[0] = ReflectionHelper.clickButtonById(ReflectionHelper.getMinecraftInstance(), fid); }
                catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
                latch.countDown();
            });
            try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
            return result[0];
        }
        return "no input handler";
    }

    protected Object handleClickButtonIndex(java.util.Map<String, String> params) {
        if (minecraftInput != null) {
            int idx = 0;
            try { idx = Integer.parseInt(params.getOrDefault("index", params.get("button_index"))); } catch (Exception ignored) {}
            final int fidx = idx;
            final CountDownLatch latch = new CountDownLatch(1);
            final String[] result = {""};
            ReflectedInputHandler.executeOnRenderThread(() -> {
                try { result[0] = ReflectionHelper.clickButtonByIndex(ReflectionHelper.getMinecraftInstance(), fidx); }
                catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
                latch.countDown();
            });
            try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
            return result[0];
        }
        return "no input handler";
    }

    protected Object handleEnumerateWidgets(java.util.Map<String, String> params) {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.enumerateWidgets(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleCallScreenMethod(java.util.Map<String, String> params) {
        String methodName = params.get("method");
        if (methodName == null || methodName.isEmpty()) methodName = params.get("methodName");
        if (methodName == null) return "missing method";
        final String fm = methodName;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.callScreenMethod(ReflectionHelper.getMinecraftInstance(), fm); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handlePasteText(java.util.Map<String, String> p) {
        String text = p.get("text");
        if (text == null) return "missing text";
        if (minecraftInput != null) {
            minecraftInput.pasteText(text);
            if ("true".equals(p.get("press_enter"))) {
                minecraftInput.pressKey("Enter", 0f);
            }
        }
        return text;
    }

    protected Object handleSetViewAngle(java.util.Map<String, String> p) {
        float yaw = 0f, pitch = 0f;
        try { yaw = Float.parseFloat(p.get("yaw")); } catch (Exception ignored) {}
        try { pitch = Float.parseFloat(p.get("pitch")); } catch (Exception ignored) {}
        if (minecraftInput != null) minecraftInput.setViewAngle(yaw, pitch);
        return "yaw=" + yaw + ",pitch=" + pitch;
    }

    protected Object handleLookDelta(java.util.Map<String, String> p) {
        float deltaYaw = 0f, deltaPitch = 0f;
        try { deltaYaw = Float.parseFloat(p.get("delta_yaw")); } catch (Exception ignored) {}
        try { deltaPitch = Float.parseFloat(p.get("delta_pitch")); } catch (Exception ignored) {}
        if (minecraftInput != null) minecraftInput.lookDelta(deltaYaw, deltaPitch);
        return "deltaYaw=" + deltaYaw + ",deltaPitch=" + deltaPitch;
    }

    protected Object handleRightClick() {
        if (minecraftInput != null) {
            final CountDownLatch latch = new CountDownLatch(1);
            final String[] result = {""};
            ReflectedInputHandler.executeOnRenderThread(() -> {
                try { result[0] = ReflectionHelper.doRightClick(ReflectionHelper.getMinecraftInstance()); }
                catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
                latch.countDown();
            });
            try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
            return result[0];
        }
        return "no input handler";
    }

    protected Object handleUseItem() {
        if (minecraftInput != null) return ReflectionHelper.doUseItem(ReflectionHelper.getMinecraftInstance());
        return "no input handler";
    }

    protected Object handlePlaceBlock() {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.doPlaceBlock(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handlePauseGame() {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.openPauseMenu(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleOpenChat() {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.openChatScreen(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleCloseScreen() {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.closeScreen(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleReleaseMouse() {
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.releaseMouse(ReflectionHelper.getMinecraftInstance()); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleSetGameMode(java.util.Map<String, String> params) {
        String mode = params.getOrDefault("mode", "creative");
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.setGameMode(ReflectionHelper.getMinecraftInstance(), mode); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }

    protected Object handleSwitchTab(java.util.Map<String, String> params) {
        int tabIndex = 0;
        try { tabIndex = Integer.parseInt(params.getOrDefault("index", params.get("tab_index"))); } catch (Exception ignored) {}
        final int fidx = tabIndex;
        final CountDownLatch latch = new CountDownLatch(1);
        final String[] result = {""};
        ReflectedInputHandler.executeOnRenderThread(() -> {
            try { result[0] = ReflectionHelper.switchTab(ReflectionHelper.getMinecraftInstance(), fidx); }
            catch (Exception e) { result[0] = "{\"error\":\"" + e.getMessage() + "\"}"; }
            latch.countDown();
        });
        try { latch.await(5, TimeUnit.SECONDS); } catch (Exception ignored) {}
        return result[0];
    }



}
