package xyz.langyo.minecraft.mcp.mod;

import xyz.langyo.minecraft.mcp.common.*;
import net.fabricmc.api.ClientModInitializer;

public class ModDevMcpMod implements ClientModInitializer {
    public static ModDevMcpMod INSTANCE;
    private McpHttpServer httpServer;
    private ReflectedInputHandler handler;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        handler = new ReflectedInputHandler(ReflectedInputHandler::executeOnRenderThread);
        int port = McpConfig.getServerPort();
        httpServer = new McpHttpServer(handler, port);
        new Thread(() -> {
            try {
                Thread.sleep(5000);
                try { Object mc = ReflectionHelper.getMinecraftInstance(); if (mc != null) ReflectionHelper.setMinecraftInstance(mc); } catch (Exception ignored) {}
                httpServer.start();
            } catch (Exception e) {
                System.err.println("[MCP-MOD] HTTP server failed: " + e.getMessage());
            }
        }, "MCP-HTTP").start();
    }

    public void onClientTick() {
        try {
            Object mc = ReflectionHelper.getMinecraftInstance();
            if (mc != null) ReflectionHelper.setMinecraftInstance(mc);
            ReflectionHelper.tickMouseRelease(mc);
            ReflectionHelper.tickMcpControlMode(mc);
        } catch (Exception ignored) {}
    }

    // ---- render hooks called by the version mixins / events (no-ops on this era) ----
    public void onInGameHudRender(Object ctx, float tickDelta) {}

    public void onScreenRender(Object ctx, Object screen, int mouseX, int mouseY, float tickDelta) {}

    public void onScreenRender(Object screen, int mouseX, int mouseY, float tickDelta) {}

    public boolean onMouseButtonEvent(Object mc, double mx, double my, int button) {
        return false;
    }

    public boolean onMouseClicked(double mx, double my, int button) {
        return false;
    }
}
